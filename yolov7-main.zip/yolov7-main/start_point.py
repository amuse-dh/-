from meida_pipe_test import hand

# frame cnt를 0으로 손 감지 시작
hand(0)