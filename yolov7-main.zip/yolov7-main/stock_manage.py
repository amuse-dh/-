import pandas as pd

def stock_management(vote_path):
    # 이전 재고 현황

    with open(vote_path, "r") as file:
        cur_stock = file.readlines()
        cur_stock = [line.strip() for line in cur_stock]

        cls0_cnt = cur_stock.count('ice_cream')
        cls1_cnt = cur_stock.count('beef_curry')
        cls2_cnt = cur_stock.count('original_curry')
        cls3_cnt = cur_stock.count('beef_black_sauce')
        cls4_cnt = cur_stock.count('original_black_sauce')
        cls5_cnt = cur_stock.count('soda')
        cls6_cnt = cur_stock.count('ediya_original')
        cls7_cnt = cur_stock.count('ediya_mild')

    df = pd.read_csv("C:/Users/user/Desktop/result.csv")

    stock = []


    for j in range(len(df)):
        object = df.iloc[j]['product']

        if object == "ice_cream":
            class_num = 0
            cur_cnt = cls0_cnt
            price = 1000
        elif object == "beef_curry":
            class_num = 1
            cur_cnt = cls1_cnt
            price = 2000
        elif object == "original_curry":
            class_num = 2
            cur_cnt = cls2_cnt
            price = 3000
        elif object == "beef_black_sauce":
            class_num = 3
            cur_cnt = cls3_cnt
            price = 4000
        elif object == "original_black_sauce":
            class_num = 4
            cur_cnt = cls4_cnt
            price = 5000
        elif object == "soda":
            class_num = 5
            cur_cnt = cls5_cnt
            price = 6000
        elif object == "ediya_original":
            class_num = 6
            cur_cnt = cls6_cnt
            price = 7000
        elif object == "ediya_mild":
            class_num = 7
            cur_cnt = cls7_cnt
            price = 8000
        else:
            continue

        price = cur_cnt * price
        diff = df.at[class_num, 'cnt'] - cur_cnt

        # 차연산을 통한 입출고 확인 및 재고 상태 업데이트
        if diff >= 0:
            #출고
            df.iloc[[class_num], [1]] = cur_cnt
            stock.append({'product': object, 'diff': cur_cnt, 'price': price, 'state': "출고"})

        else:
            #입고
            df.iloc[[class_num], [1]] = cur_cnt
            stock.append({'product': object, 'diff': cur_cnt, 'price': price, 'state': "출고"})

    df.to_csv("C:/Users/user/Desktop/result.csv", index=False, mode='w')
    stock_df = pd.DataFrame(stock, columns=['product', 'diff', 'price', 'state'])
    stock_df.to_csv('C:/Users/user/Desktop/stock.csv', index=False, mode='w')











'''
def stock_management(vote_path):
    # 이전 재고 현황

    with open(vote_path, "r") as file:
        cur_stock = file.readlines()
        cur_stock = [line.strip() for line in cur_stock]
        print(cur_stock)
        cls0_cnt = cur_stock.count('ice_cream')
        cls1_cnt = cur_stock.count('soda')
        cls2_cnt = cur_stock.count('cup_rice')
        cls3_cnt = cur_stock.count('oreo')
        cls4_cnt = cur_stock.count('ediya')
        cls5_cnt = cur_stock.count('curry')
        cls6_cnt = cur_stock.count('ham')
        cls7_cnt = cur_stock.count('febreeze')
        cls8_cnt = cur_stock.count('cantata')
        print(cls0_cnt)
        print(cls1_cnt)
        print(cls2_cnt)
        print(cls3_cnt)
        print(cls4_cnt)
        print(cls5_cnt)
        print(cls6_cnt)
        print(cls7_cnt)
        print(cls8_cnt)

    df = pd.read_csv("C:/Users/user/Desktop/result.csv")

    stock = []

    for i in cur_stock:
        print(i)

        for j in range(len(df)):

            if i == df.iloc[j]['product']:
                if i == "ice_cream":
                    class_num = 0
                    cur_cnt = cls0_cnt
                    price = 1000
                elif i == "soda":
                    class_num = 1
                    cur_cnt = cls1_cnt
                    price = 1000
                elif i == "cup_rice":
                    class_num = 2
                    cur_cnt = cls2_cnt
                    price = 1000
                elif i == "oreo":
                    class_num = 3
                    cur_cnt = cls3_cnt
                    price = 1000
                elif i == "ediya":
                    class_num = 4
                    cur_cnt = cls4_cnt
                    price = 1000
                elif i == "curry":
                    class_num = 5
                    cur_cnt = cls5_cnt
                    price = 1000
                elif i == "ham":
                    class_num = 6
                    cur_cnt = cls6_cnt
                    price = 1000
                elif i == "febreeze":
                    class_num = 7
                    cur_cnt = cls7_cnt
                    price = 1000
                else:
                    class_num = 8
                    cur_cnt = cls8_cnt
                    price = 1000

                price = cur_cnt * price
                df.iloc[[class_num],[1]] = df.iloc[[class_num],[1]] - cur_cnt
                stock.append({'product': i, 'diff': cur_cnt, 'price': price})

            else:
                continue
    df.to_csv("C:/Users/user/Desktop/result.csv", index=False, mode='w')
    print(df)
    stock_df = pd.DataFrame(stock, columns=['product','diff','price'])
    print(stock_df)
    stock_df.to_csv('C:/Users/user/Desktop/stock.csv', index=False, mode='w')

'''