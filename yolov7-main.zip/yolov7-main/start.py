cap_btn = tk.Button(app,text='촬영', width=20, height=5, command=capture_button)
tk.Button.grid_configure(cap_btn, column=100)
cap_btn.pack()