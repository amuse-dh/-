from tkinter import *
import tkinter as tk
import pandas as pd
from tksheet import Sheet
from capture_img import capture

import tkinter as tk
from tksheet import Sheet
import pandas as pd
import time

def close_after_20_seconds(root):
    root.after(20000, root.destroy)

def show_csv_in_tksheet(file_path):
    # CSV 파일을 DataFrame으로 읽어오기
    df = pd.read_csv(file_path)

    # Tkinter 창 생성
    root = tk.Tk()
    root.title("CSV Viewer")

    # tksheet을 사용하여 DataFrame을 표시
    sheet = Sheet(root, data=df.values.tolist(), headers=list(df.columns), width=600, height=300)
    sheet.grid(row=0, column=0)

    # 20초 후에 창을 자동으로 닫기
    close_after_20_seconds(root)

    # Tkinter 이벤트 루프 시작
    root.mainloop()



'''
def capture_button():
    print(1)
    capture()


def close_after_30_seconds():
    app.destroy()

def update_data():
    app.sheet.set_sheet_data(pd.read_csv("C:/Users/user/Desktop/result.csv").values.tolist())
    app.after(3000,update_data)

class Demo(tk.Tk):
    def __init__(self, path):
        tk.Tk.__init__(self)
        self.path = path
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.frame = tk.Frame(self)
        self.frame.grid_columnconfigure(100, weight=1)
        self.frame.grid_rowconfigure(100, weight=1)
        self.sheet = Sheet(
            self.frame,
            data=pd.read_csv(
                path,  # filepath here
            ).values.tolist(),
        )
        self.sheet.enable_bindings()
        self.frame.grid(row=0, column=0, sticky="nswe")
        self.sheet.grid(row=0, column=0, sticky="nswe")

        label1 = Label(self.frame)
        label1.grid(row=1, column=1)


app = Demo("C:/Users/user/Desktop/result.csv")
update_data()
app.mainloop()
'''
'''

from tkinter import *
import tkinter as tk
import pandas as pd
from tksheet import Sheet
from capture_img import capture

def update_data():
    app.sheet.set_sheet_data(pd.read_csv("C:/Users/user/Desktop/result.csv").values.tolist())
    app.after(3000, update_data)

def close_after_30_seconds():
    app.destroy()

class Demo(tk.Tk):
    def __init__(self, path):
        tk.Tk.__init__(self)
        self.path = path
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.frame = tk.Frame(self)
        self.frame.grid_columnconfigure(100, weight=1)
        self.frame.grid_rowconfigure(100, weight=1)
        self.sheet = Sheet(
            self.frame,
            data=pd.read_csv(
                path,
            ).values.tolist(),
        )
        self.sheet.enable_bindings()
        self.frame.grid(row=0, column=0, sticky="nswe")
        self.sheet.grid(row=0, column=0, sticky="nswe")

        label1 = Label(self.frame)
        label1.grid(row=1, column=1)

app = Demo("C:/Users/user/Desktop/result.csv")
update_data()

# Set a timer to close the application after 30 seconds
app.after(30000, close_after_30_seconds)

app.mainloop()

'''