'''
import cv2
import os
import subprocess

def capture():
    file_dir = "./capture/"
    cameras = cv2.VideoCapture(0)

    try:
        for i in range(30):
            ret, frame = cameras.read()
        if not ret:
            print("카메라로부터 프레임을 읽을 수 없음.")
        else:
            file_path = "0.jpg"
            cv2.imwrite(file_dir + file_path, frame)
            print("1")

            # subprocess를 사용하여 비동기적으로 명령어 실행
            command = "python detect.py --weights C:/Users/user/PycharmProjects/yolov7-main/runs/train/freeze_yolov78/weights/best.pt --conf 0.7 --iou 0.2 --save-txt --source C:/Users/user/PycharmProjects/yolov7-main/capture/0.jpg --name test"
            subprocess.Popen(command, shell=True)

    finally:
        cameras.release()
        print("2")
'''


import subprocess
import cv2
import os

# 각 뷰 별 이미지 캡처
def capture():
    file_dir = "C:/Users/user/PycharmProjects/yolov7-main/capture"
    for i in range(4):
        camera = cv2.VideoCapture(i)
        camera.set(cv2.CAP_PROP_FPS, 60)
        ret, frame = camera.read()

        if not ret:
            print(f"Cannot read frames from camera"+str(i))

        file_name = str(i) + ".jpg"

        cv2.imwrite(os.path.join(file_dir, file_name), frame)
        camera.release()

    #이미지 캡처 후 detection 실행
    command = ["python", "detect.py",
               "--weights", "C:/Users/user/PycharmProjects/yolov7-main/runs/train/no_freeze_yolov7_aug/weights/best.pt",
               "--conf", "0.7", "--iou", "0.2", "--save-txt", "--source", file_dir, "--name", "stock_manage"]

    process = subprocess.Popen(command, shell=True)
    process.wait()
