import os
import natsort
import stock_manage as manage

def voting(name):
    #결과 path 1개에서 3개 이미지 결과를 다 읽어옴
    path = str(name / "labels")
    #path = "C:/Users/user/PycharmProjects/yolov7-main/runs/detect/conven_3view/"
    i = 0

    # txt 정보 읽어옴
    path_list = os.listdir(path)
    path_list = natsort.natsorted(path_list)
    length = len(path_list)

    cls0 = []
    cls1 = []
    cls2 = []
    cls3 = []
    cls4 = []
    cls5 = []
    cls6 = []
    cls7 = []
    cls8 = []

    for cnt in range(0, length):

        with open(str(path) + "\\" + path_list[cnt], "r", encoding = "UTF-8") as file1:
            vote1 = file1.readlines()

            for i in range(len(vote1)):
                vote1[i] = vote1[i].split()
                if vote1[i][0] == "0":
                    cls0.append(1)
                elif vote1[i][0] == "1":
                    cls1.append(1)
                elif vote1[i][0] == "2":
                    cls2.append(1)
                elif vote1[i][0] == "3":
                    cls3.append(1)
                elif vote1[i][0] == "4":
                    cls4.append(1)
                elif vote1[i][0] == "5":
                    cls5.append(1)
                elif vote1[i][0] == "6":
                    cls6.append(1)
                elif vote1[i][0] == "7":
                    cls7.append(1)
                else:
                    continue

    # w전체 뷰에 대한 OD결과 투표 완료

    with open("C:/Users/user/Desktop/voting/result.txt", "w") as vote:
        if len(cls0) >= 2:
            vote.write("ice_cream\n")

        if len(cls1) >= 2:
            vote.write("beef_curry\n")

        if len(cls2) >= 2:
            vote.write("original_curry\n")

        if len(cls3) >= 2:
            vote.write("beef_black_sauce\n")

        if len(cls4) >= 2:
            vote.write("original_black_sauce\n")

        if len(cls5) >= 2:
            vote.write("soda\n")

        if len(cls6) >= 2:
            vote.write("ediya_original\n")

        if len(cls7) >= 2:
            vote.write("ediya_mild\n")

    vote_result_path = "C:/Users/user/Desktop/voting/result.txt"

    return vote_result_path



