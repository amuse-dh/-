import cv2

# 비디오 캡처 객체 생성
cap = cv2.VideoCapture(0)  # 0은 기본 카메라를 나타냅니다. 다른 카메라를 사용하려면 1, 2, 등으로 변경할 수 있습니다.

# 비디오의 속성 설정 (옵션)
cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)  # 프레임 폭 설정
cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)  # 프레임 높이 설정

while True:
    # 비디오에서 프레임 읽기
    ret, frame = cap.read()

    # 프레임이 제대로 읽어졌는지 확인
    if not ret:
        print("비디오 프레임을 읽을 수 없습니다.")
        break

    # 프레임을 화면에 표시
    cv2.imshow('Video Capture', frame)

    # 'q' 키를 누르면 종료
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# 비디오 캡처 객체와 윈도우를 해제
cap.release()
cv2.destroyAllWindows()