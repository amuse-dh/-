import cv2
import mediapipe as mp
from capture_img import capture

def hand(frame_cnt):
    mp_drawing = mp.solutions.drawing_utils
    mp_drawing_styles = mp.solutions.drawing_styles
    mp_hands = mp.solutions.hands
    # 웹캠, 영상 파일의 경우 이것을 사용하세요.:
    cap = cv2.VideoCapture(0)

    previous_state = 0
    state = 0

    with mp_hands.Hands(
        model_complexity=0,
        min_detection_confidence=0.5,
        min_tracking_confidence=0.5) as hands:
      while cap.isOpened():
        success, image = cap.read()
        if not success:
          print("카메라를 찾을 수 없습니다.")
          # 동영상을 불러올 경우는 'continue' 대신 'break'를 사용합니다.
          continue



        # 필요에 따라 성능 향상을 위해 이미지 작성을 불가능함으로 기본 설정합니다.
        image.flags.writeable = False
        image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        results = hands.process(image)

        # 이미지에 손 주석을 그립니다.
        image.flags.writeable = False
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)


        # state 결정
        if results.multi_hand_landmarks:
            # 손이 있을 때 상태 업데이트
            if previous_state == 0 and state == 0:
                state = 1
                print("state :",state)
                print("previous state :", previous_state)
            elif previous_state == 0 and state == 1:

                previous_state = 1
                state = 1
                print("state :", state)
                print("previous state :", previous_state)
            elif previous_state == 1 and state == 0:

                previous_state = 1
                state = 1
                print("state :", state)
                print("previous state :", previous_state)
            else:
                previous_state = 1
                state = 1
                print("state :", state)
                print("previous state :", previous_state)

        else:
            # 손이 없을 때 상태 업데이트
            if previous_state == 0 and state == 0:
                # 01
                previous_state = 0
                state = 0
                print("state :", state)
                print("previous state :", previous_state)
            elif previous_state == 0 and state == 1:
                # 11
                previous_state = 1
                state = 0
                print("state :", state)
                print("previous state :", previous_state)
            elif previous_state == 1 and state == 0:
                # 11
                previous_state = 0
                state = 0
                print("state :", state)
                print("previous state :", previous_state)
            else:
                # 유지
                previous_state = 1
                state = 0
                print("state :", state)
                print("previous state :", previous_state)

        # 이전 상태와 현재 상태를 통해 frame cnt 0 초기화 및 카운팅
        if previous_state == 0 and state == 0:

            frame_cnt = frame_cnt + 1
            print("frame cnt :", frame_cnt)
        elif previous_state == 0 and state == 1:

            frame_cnt = 0
            print("frame cnt :", frame_cnt)
        elif previous_state == 1 and state == 0:

            frame_cnt += 1
            print("frame cnt :", frame_cnt)
        else:
            frame_cnt = 0
            print("frame cnt :", frame_cnt)

        if frame_cnt == 150:
            #capture실행
            break
        elif frame_cnt > 150:
            continue
        else:
            continue

    cap.release()
    capture()

